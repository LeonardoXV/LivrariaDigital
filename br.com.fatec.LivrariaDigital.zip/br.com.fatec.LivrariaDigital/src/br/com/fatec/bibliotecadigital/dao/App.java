package br.com.fatec.bibliotecadigital.dao;

import br.com.fatec.bibliotecadigital.entidades.Autor;
import br.com.fatec.bibliotecadigital.entidades.Categoria;
import br.com.fatec.bibliotecadigital.entidades.Editora;
import br.com.fatec.bibliotecadigital.entidades.Livro;
import br.com.fatec.bibliotecadigital.entidades.PedidosParaEditora;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {

    
    public static void main(String[] args) {
        EntityManagerFactory ent=Persistence.createEntityManagerFactory("persistence");
        DaoCreate dao=new DaoCreate(ent);
        
        Date data=new Date("05/09/1995");
        
        Categoria categoria=new Categoria("comedia");
        List<Categoria>categorias=new ArrayList();
        categorias.add(categoria);
        dao.inserir(categoria);
        
        Autor autor=new Autor("Leo Vieira", data, data,"São Paulo","Canada","Homem de Honra");
        Autor autor1=new Autor("Leo Vieira", data, data,"São Paulo","Canada","Homem de Honra");
        dao.inserir(autor);
        dao.inserir(autor1);
        
        Editora editora=new Editora("cnpj","nome","endereco", "Telefone");
        dao.inserir(editora);
        
        List<Autor>autores=new ArrayList();
        autores.add(autor);
        autores.add(autor1);
        
        Livro livro=new Livro("isbn","Titulo","resumo","Indice","formato", 50, data, categorias,500, editora,autores);
        dao.inserir(livro);
        
        List<Autor>autores1=new ArrayList();
        autores1.add(autor1);
      
        Livro livro1=new Livro("isbn","Titulo","resumo","Indice","formato", 50, data, categorias,500, editora,autores1);
        dao.inserir(livro1);
        
        List<Livro>livros=new ArrayList();
        livros.add(livro);
        PedidosParaEditora pe=new PedidosParaEditora(livros, data);
        dao.getEntityManagerFactory().close();
    }
    
}