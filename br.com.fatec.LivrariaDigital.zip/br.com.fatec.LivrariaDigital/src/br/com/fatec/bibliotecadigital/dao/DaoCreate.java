
package br.com.fatec.bibliotecadigital.dao;

import java.io.Serializable;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;


public class DaoCreate {
    private final EntityManagerFactory entityManagerFactory;
    private final EntityManager entityManager;

    public DaoCreate(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        this.entityManager=entityManagerFactory.createEntityManager();
    }
    
    public void inserir(Serializable serializable){
        
        this.entityManager.getTransaction().begin();
        this.entityManager.persist(serializable);
        this.entityManager.getTransaction().commit();
    }

    public EntityManagerFactory getEntityManagerFactory() {
        return entityManagerFactory;
    }
    
    
    
    
    
    
    
}
