
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "Tb_Livros")
@SecondaryTable(name = "Tb_DetalhesLivro")
public class Livro implements Serializable {

    
   
    private int idLivro;
    private String isbn;
    private  String Titulo;
    private List<PedidosParaEditora> pedidosParaEditora;
    private String resumo;
    private String indice;
    private String Formato;
    private int numPaginas;
    private Date dataPublicacao;
    private List<Categoria> categorias;
    private double precoDeVenda;
    private List<Autor> autores;
    private Editora editora;
   
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_IdLivro")
    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }
 
    
    @Column(name = "C_IsbnLivr")
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    
    @Column(name = "C_TituLivr")
    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String Titulo) {
        this.Titulo = Titulo;
    }
    
    @ManyToMany(mappedBy = "livros")
    public List<PedidosParaEditora> getPedidosParaEditora() {
        return pedidosParaEditora;
    }

    public void setPedidosParaEditora(List<PedidosParaEditora> pedidosParaEditora) {
        this.pedidosParaEditora = pedidosParaEditora;
    }
    
    @Column(name = "C_resuLivr",table = "Tb_DetalhesLivro")
    public String getResumo() {
        return resumo;
    }

    public void setResumo(String resumo) {
        this.resumo = resumo;
    }
    
    @Column(name = "C_IndiLivr",table = "Tb_DetalhesLivro")
    public String getIndice() {
        return indice;
    }

    public void setIndice(String indice) {
        this.indice = indice;
    }
    
    @Column(name = "C_FormLivr",table = "Tb_DetalhesLivro")
    public String getFormato() {
        return Formato;
    }

    public void setFormato(String Formato) {
        this.Formato = Formato;
    }
    
    @Column(name = "N_NumePagi",table = "Tb_DetalhesLivro")
    public int getNumPaginas() {
        return numPaginas;
    }

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }
    
    @Column(name = "D_DataPubl",table = "Tb_DetalhesLivro")
    public Date getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(Date dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }
    
    @ManyToMany
    @JoinTable(name="Tb_LivrosPorCategoria", joinColumns={@JoinColumn(name="N_IdLivro")}, inverseJoinColumns={@JoinColumn(name="N_IdCatego")})
    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }
    
    @Column(name = "N_PrecVend",table = "Tb_DetalhesLivro")
    public double getPrecoDeVenda() {
        return precoDeVenda;
    }

    public void setPrecoDeVenda(double precoDeVenda) {
        this.precoDeVenda = precoDeVenda;
    }
    
    @ManyToMany
    @JoinTable(name = "Tb_LivrosPorAutor",joinColumns = {@JoinColumn(name = "N_IdLivro")},inverseJoinColumns = {@JoinColumn(name = "N_IdAutor")})
    public List<Autor> getAutores() {
        return autores;
    }

    public void setAutores(List<Autor> autores) {
        this.autores = autores;
    }
    
    @ManyToOne
    @JoinColumn(name = "N_IdEditor")
    public Editora getEditora() {
        return editora;
    }

    public void setEditora(Editora editora) {
        this.editora = editora;
    }
    
    
    

    public Livro(String isbn, String Titulo, String resumo, String indice, String Formato, int numPaginas, Date dataPublicacao, List<Categoria> categorias, double precoDeVenda,Editora editora,List<Autor>autores) {
        this.isbn = isbn;
        this.Titulo = Titulo;
        this.resumo = resumo;
        this.indice = indice;
        this.Formato = Formato;
        this.numPaginas = numPaginas;
        this.dataPublicacao = dataPublicacao;
        this.categorias = categorias;
        this.precoDeVenda = precoDeVenda;
        this.editora=editora;
        this.autores=autores;
        
     
    }

    public Livro() {
    }
    
    
    


 
    
    
    
    
    
    
    
    
    
}
