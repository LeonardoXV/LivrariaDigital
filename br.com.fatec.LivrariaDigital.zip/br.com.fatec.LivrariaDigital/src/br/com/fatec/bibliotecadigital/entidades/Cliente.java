
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "Tb_Clientes")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@DiscriminatorColumn(name = "tipo_de_Usuario",discriminatorType =DiscriminatorType.STRING)
@DiscriminatorValue("F")
public class Cliente implements Serializable {

    
    private String nomeDeUsuario;
    
    private String emailCliente;
    private String nome;
    private String sobreNome;
    private String senha;
    private Date dataNasc;
    private char sexo;
    private String cpf;

    public Cliente() {
    }

    public Cliente(String nomeDeUsuario, String emailCliente, String nome, String sobreNome, String senha, Date dataNasc, char sexo, String cpf) {
        this.nomeDeUsuario = nomeDeUsuario;
        this.emailCliente = emailCliente;
        this.nome = nome;
        this.sobreNome = sobreNome;
        this.senha = senha;
        this.dataNasc = dataNasc;
        this.sexo = sexo;
        this.cpf = cpf;
    }
    
    

    @Id
    @Column(name = "C_NomeUsua")
    public String getNomeDeUsuario() {
        return nomeDeUsuario;
    }

    public void setNomeDeUsuario(String nomeDeUsuario) {
        this.nomeDeUsuario = nomeDeUsuario;
    }
    
    @Column(name = "C_EmailUsu")
    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }
    
    @Column(name = "C_NomeClie")
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    @Column(name = "C_SobrNome")
    public String getSobreNome() {
        return sobreNome;
    }

    public void setSobreNome(String sobreNome) {
        this.sobreNome = sobreNome;
    }
    
    @Column(name = "C_SenhClie")
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    @Column(name = "D_DataNasc")
    public Date getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }
    
    @Column(name = "C_SexoClie")
    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }
    
    @Column(name = "C_CpfClien")
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    
}
