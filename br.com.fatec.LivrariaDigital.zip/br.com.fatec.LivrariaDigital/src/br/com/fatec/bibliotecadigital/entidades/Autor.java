/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "Tb_Autores")
public class Autor implements Serializable  {
    
    
    private int IdAutor;
    private String Nome;
    private Date dataNasce;
    private Date dataFale;
    private String localNasc;
    private String localMorte;
    private String biografia;
    private List<Livro> livros;
    private List<Editora> editoras;

    public Autor() {
    }

    public Autor(String Nome, Date dataNasce, Date dataFale, String localNasc, String localMorte, String biografia) {
        this.Nome = Nome;
        this.dataNasce = dataNasce;
        this.dataFale = dataFale;
        this.localNasc = localNasc;
        this.localMorte = localMorte;
        this.biografia = biografia;
        
        
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "N_IdAutor")
    public int getIdAutor() {
        return IdAutor;
    }

    public void setIdAutor(int IdAutor) {
        this.IdAutor = IdAutor;
    }
    
    
    @Column(name = "nome")
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    
    @Column(name = "datanasc")
    public Date getDataNasce() {
        return dataNasce;
    }

    public void setDataNasce(Date dataNasce) {
        this.dataNasce = dataNasce;
    }
    
    @Column(name = "dataFa")
    public Date getDataFale() {
        return dataFale;
    }

    public void setDataFale(Date dataFale) {
        this.dataFale = dataFale;
    }
    
    @Column(name = "localnasx")
    public String getLocalNasc() {
        return localNasc;
    }

    public void setLocalNasc(String localNasc) {
        this.localNasc = localNasc;
    }
    
    @Column(name = "LocalMo")
    public String getLocalMorte() {
        return localMorte;
    }

    public void setLocalMorte(String localMorte) {
        this.localMorte = localMorte;
    }
    
    @Column(name = "bibliogra")
    public String getBiografia() {
        return biografia;
    }

    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }
    
    @ManyToMany(mappedBy = "autores")
    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }
    
    @ManyToMany(mappedBy = "autores")
    public List<Editora> getEditoras() {
        return editoras;
    }

    public void setEditoras(List<Editora> editoras) {
        this.editoras = editoras;
    }
    
  
    
    
  
    
    

       
}
