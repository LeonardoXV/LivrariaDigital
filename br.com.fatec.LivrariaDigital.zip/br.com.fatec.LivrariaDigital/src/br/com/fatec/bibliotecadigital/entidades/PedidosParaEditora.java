
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Tb_PedidosParaEditora")
public class PedidosParaEditora implements Serializable {
    
    private int IdPedidoEditora;
    private List<Livro> livros;
    private Date dataPedido;
   

    public PedidosParaEditora() {
    }
    
    @Id
    @Column(name = "N_IdPediEd")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getIdPedidoEditora() {
        return IdPedidoEditora;
    }

    public void setIdPedidoEditora(int IdPedidoEditora) {
        this.IdPedidoEditora = IdPedidoEditora;
    }
    
    @ManyToMany
    @JoinTable(name = "Tb_livrosPedidos",joinColumns = {@JoinColumn(name = "N_IdPediEd")},inverseJoinColumns = {@JoinColumn(name = "N_IdLivro")})
    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }
    
    @Column(name = "D_dataPedido")
    public Date getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(Date dataPedido) {
        this.dataPedido = dataPedido;
    }


    public PedidosParaEditora(List<Livro> livros, Date dataPedido) {
        this.livros = livros;
        this.dataPedido = dataPedido;
       
        
    }
    
    
    
    


    
    
    
}
