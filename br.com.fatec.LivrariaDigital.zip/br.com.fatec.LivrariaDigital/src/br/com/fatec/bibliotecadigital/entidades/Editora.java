
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Tb_Editoras")
public class Editora implements Serializable {
    
    
    private int IdEditora;
    private String cnpj;
    private String nome;
    private String Endereco;
    private String telefone;
    private List<Livro>livros;
    private List<Autor>autores;
    
    
    
    public Editora() {
    }

    public Editora(String cnpj, String nome, String Endereco, String telefone) {
        this.cnpj = cnpj;
        this.nome = nome;
        this.Endereco = Endereco;
        this.telefone = telefone;
       
    }
    
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "N_IdEditor")
    public int getIdEditora() {
        return IdEditora;
    }
    
    
    public void setIdEditora(int IdEditora) {
        this.IdEditora = IdEditora;
    }
    
    @Column(name = "N_CnpjEdit")
    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
    
    @Column(name = "C_nomeEdit")
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    @Column(name="C_EndeEdit")
    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }
    
    @Column(name = "C_TeleEdit")
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    @OneToMany
    @JoinColumn(name = "N_IdEditor")
    public List<Livro> getLivros() {
        return livros;
    }
    
    
    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }
    
    @ManyToMany
    @JoinTable(name = "Tb_AutoresPorEditoras",joinColumns = {@JoinColumn(name = "N_IdEditor")},inverseJoinColumns = {@JoinColumn(name = "N_IdAutor")})
    public List<Autor> getAutores() {
        return autores;
    }

    public void setAutores(List<Autor> autores) {
        this.autores = autores;
    }
    
    
}
