
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TB_PedidosPorCliente")
public class PedidosPorCliente implements Serializable {
    
 
    private int idPedido;
    private Date dataDeCompra;
    private List<Livro> livros;
    private Cliente cliente;
    private double valorTotal;

    public PedidosPorCliente() {
    }

    @Id
    @Column(name = "N_IdPedido")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getIdPedido() {
        return idPedido;
    }
    
    @Column(name = "D_dataComp")
    public Date getDataDeCompra() {
        return dataDeCompra;
    }

    public void setDataDeCompra(Date dataDeCompra) {
        this.dataDeCompra = dataDeCompra;
    }
    
    @ManyToMany
    @JoinTable(name="Tb_HistoriDePedidos", joinColumns={@JoinColumn(name="N_IdPedido")}, inverseJoinColumns={@JoinColumn(name="N_IdLivro")})
    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        
        this.livros = livros;
    }
    
    @ManyToOne
    @JoinColumn(name = "C_NomeUsua")
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    @Column(name = "N_ValoPedi")
    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public PedidosPorCliente(Date dataDeCompra, List<Livro> livros, Cliente cliente, double valorTotal) {
        this.dataDeCompra = dataDeCompra;
        this.livros = livros;
        this.cliente = cliente;
        this.valorTotal = valorTotal;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }
    
    

   
   
    
    
    
}
