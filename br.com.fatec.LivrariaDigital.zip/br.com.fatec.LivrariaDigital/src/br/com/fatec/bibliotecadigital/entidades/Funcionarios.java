/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.bibliotecadigital.entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Tb_Funcionarios")
public class Funcionarios extends Cliente{
    
    
    

    private  String Cargo;
    private double salario;
    private String rg;

    
    public Funcionarios() {
    }

    public Funcionarios(String Cargo, double salario, String rg, String nomeDeUsuario, String emailCliente, String nome, String sobreNome, String senha, Date dataNasc, char sexo, String cpf) {
        super(nomeDeUsuario, emailCliente, nome, sobreNome, senha, dataNasc, sexo, cpf);
        this.Cargo = Cargo;
        this.salario = salario;
        this.rg = rg;
    }
    
    @Column(name = "C_CargoFun")
    public String getCargo() {
        return Cargo;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }
    
    @Column(name = "N_SalaFunc")
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    @Column(name = "C_RgFuncion")
    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }
   
    
   
    

    
    
}
