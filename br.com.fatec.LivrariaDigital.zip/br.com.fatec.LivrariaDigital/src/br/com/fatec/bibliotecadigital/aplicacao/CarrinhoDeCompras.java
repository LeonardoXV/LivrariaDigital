
package br.com.fatec.bibliotecadigital.aplicacao;

import br.com.fatec.bibliotecadigital.entidades.Livro;
import java.util.ArrayList;
import java.util.List;

public class CarrinhoDeCompras {
    
    private List<Livro>livros=new ArrayList();
    private void adicionarLivro(Livro livro){
        livros.add(livro);
    }
    
    private void removerLivro(Livro livro){
        this.livros.remove(livro);
    }
    
}
